cp  -R  /var/lib/go-agent/pipelines/Chronicity-Example-Build/Utilities/databrowser/build/*  /var/www/viewex.chronicity.io/
